# Главный файл urls.py (рядом с settings.py)
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('TourClub.urls')),  # Подключаем маршруты приложения
]