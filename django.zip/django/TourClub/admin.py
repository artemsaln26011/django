from django.contrib import admin

# Регистрация моделей (если они появятся в models.py)
# from .models import Tour
# admin.site.register(Tour)