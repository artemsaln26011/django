import django.shortcuts 

def index(request):
    return django.shortcuts.render(request, 'home.html')

def about(request):
    return django.shortcuts.render(request, 'about.html')

def contacts(request):
    return django.shortcuts.render(request, 'contacts.html')

def how_to_find(request):
    return django.shortcuts.render(request, 'how_to_find.html')

def tours(request):
    return django.shortcuts.render(request, 'tours.html')

def equipment(request):
    return django.shortcuts.render(request, 'equipment.html')