from django.db import models

# Здесь пока пусто, так как данные для страниц заданы статично в шаблонах.
# class Tour(models.Model):
#     title = models.CharField(max_length=200)
#     description = models.TextField()
#     price = models.DecimalField(max_digits=10, decimal_places=2)
#
#     def __str__(self):
#         return self.title