# Файл TourClub/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('about/', views.about, name='about'),
    path('about/contacts/', views.contacts, name='contacts'),
    path('about/how-to-find/', views.how_to_find, name='how_to_find'),
    path('tours/', views.tours, name='tours'),
    path('equipment/', views.equipment, name='equipment'),
]