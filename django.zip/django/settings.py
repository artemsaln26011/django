
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'TourClub',  # Регистрация нашего приложения
]
ALLOWED_HOSTS = ['127.0.0.1', 'localhost', '192.168.1.50'] # Замените на ваш IP